#include<iostream>
#include <fstream>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#define PORT 4444

using namespace std;

int main(int argc, char** argv) {
  int cliSockDes, readStatus, len;
  struct sockaddr_in serAddr,cliAddr;
  char msg[] = "Broadcast message from SLAVE TAG!!!\n";
  char rbuff[1024] = {0};
  
  int broadcast = 1;

  cout<<"create a socket\n";
  if((cliSockDes = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    perror("socket creation error...\n");
    exit(-1);
  }
  
  if(setsockopt(cliSockDes, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast)) <0)
   {
   
    perror("socket set error...\n");
    exit(-1);
   }
 

//  cout<<"server socket address\n";
  serAddr.sin_family = AF_INET;
  serAddr.sin_port = htons(PORT);
  serAddr.sin_addr.s_addr = INADDR_BROADCAST;
//cout<<"sending msg now";
  sendto(cliSockDes, msg, strlen(msg)+1, 0, (struct sockaddr*)&serAddr, sizeof(struct sockaddr_in));
//cout<<"send msg";
//cout<<"receving reply from server";
  readStatus = recvfrom(cliSockDes, rbuff, 1024, 0, (struct sockaddr*)&cliAddr,(socklen_t*)&len);
  rbuff[readStatus] = '\0';
  cout<<rbuff;
  cout<<"Message received\n";

  return 0;
}
