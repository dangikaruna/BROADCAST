#ifndef _UDP_SERVER_H_
#define _UDP_SERVER_H_
#include "udp_ServerProperty.h"
#include "udp_exception.h"

class udp_unicast:public udp_ServerProperty{
    public:   
        void signal_Handler(int signal);       // it is for clean exiting and freeing the port and others.
        int createSocket();
        void bindSocket(int* udpSocket);
        void sendReceiveData(int* udpSocket);
        void sendFrame(int* udpSocket, struct sockaddr_in *server_addr, struct sockaddr_in *client_addr);
        void udpUnicast();
        udp_unicast();
        ~udp_unicast();
};
class udp_Multicast:public udp_ServerProperty{
    public:
        void udpMulticast();
        udp_Multicast();
        ~udp_Multicast();
};

class udp_Broadcast:public udp_ServerProperty{
    public:
        void signal_Handler(int signal);
        int createSocket();
        void bindSocket(int* udpSocket);
        void sendReceiveData(int* udpSocket);
        void udpBroadcast();
        udp_Broadcast();
        ~udp_Broadcast();
};

class UDP_Server{
    public:
        void selectOperation();
        //void Driver();
        void Driver();
};
//  selectOperation();
//void selectOperation();
//void Driver();

#endif