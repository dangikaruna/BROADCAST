#ifndef UDP_CLIENTPROPERTY_H_
#define UDP_CLIENTPROPERTY_H_
#include<iostream>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<stdio.h>
#include<netinet/in.h>
#include<unistd.h>
#include<fstream>
#include<sstream>
#include<sys/stat.h>
#include<string.h>
#include <stdlib.h>
#include <signal.h>
#include<csignal>

#include "udp_Exception.h"
using namespace std;

typedef struct packet{
    char data[2048];
}Packet;


typedef struct frame{
    int frame_type;
    int sq_no;
    int ack;
    Packet packet;
}Frame;
class udp_ClientProperty{
    public:
        struct timeval time_out={0,0};
        char *IP;
        int portNumber;
        //int timeDelay;
        //int resendFrameTime;
        //int resendFrameLongPeriod;
        //int *messageLength=NULL;
        //long int *total_Frame=NULL, *bytes_received=NULL;
        //long int i=0;
        //char *receivemessage=NULL;
        // int *readMessage=NULL;
        // ssize_t *length=NULL;
        //int *messageSize=NULL;
        //int *ack_num=NULL;
        //int *ack_send=NULL;
        int *udpClientSocket=NULL;
        struct sockaddr_in server_addr, client_addr;

        int broadcast = 1;
};

#endif